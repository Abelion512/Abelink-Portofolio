"use client";

import Link from "next/link";
import { useTranslations } from "next-intl";
import { useRouter } from "next/navigation";
import { FiArrowLeftCircle as BackButtonIcon } from "react-icons/fi";

interface BackButtonProps {
  url?: string;
}

const BackButton = ({ url }: BackButtonProps) => {
  const router = useRouter();
  const t = useTranslations("ProjectsPage");

  const className =
    "flex gap-2 w-max hover:gap-3 items-center pb-5 transition-all duration-300 font-medium text-neutral-600 dark:text-neutral-400 cursor-pointer";

  const handleOnClick = () => {
    if (url) {
      window.location.href = url;
    } else {
      router.back();
    }
  };

  const BackButtonChildComponent = () => {
    return (
      <>
        <BackButtonIcon size={20} />
        <span>{t("back_button")}</span>
      </>
    );
  };

  return (
    <div className="w-fit">
      {url ? (
        <Link href={url}>
          <div className={className}>
            <BackButtonChildComponent />
          </div>
        </Link>
      ) : (
        <div className={className} onClick={handleOnClick}>
          <BackButtonChildComponent />
        </div>
      )}
    </div>
  );
};

export default BackButton;
