import { describe, expect, it, beforeEach } from "bun:test";
import { useLangStore } from "./languageStore";

describe("useLangStore", () => {
  beforeEach(() => {
    useLangStore.setState({ lang: 'en' });
  });

  it("should have default language as 'en'", () => {
    const state = useLangStore.getState();
    expect(state.lang).toBe('en');
  });

  it("should update language using setLang", () => {
    useLangStore.getState().setLang('id');
    expect(useLangStore.getState().lang).toBe('id');
  });

  it("should translate keys correctly using the production dictionaries", () => {
    // Test English
    useLangStore.setState({ lang: 'en' });
    expect(useLangStore.getState().t("hero.greeting")).toBe("Hi, I'm");

    // Test Indonesian
    useLangStore.getState().setLang('id');
    expect(useLangStore.getState().t("hero.greeting")).toBe("Halo, saya");
  });

  it("should return the key itself if translation is missing", () => {
    const t = useLangStore.getState().t;
    expect(t("non.existent.key")).toBe("non.existent.key");
  });

  it("should have consistent keys across English and Indonesian dictionaries", () => {
    const { en } = require("../i18n/en");
    const { id } = require("../i18n/id");
    
    const enKeys = Object.keys(en).sort();
    const idKeys = Object.keys(id).sort();
    
    expect(enKeys).toEqual(idKeys);
  });
});
