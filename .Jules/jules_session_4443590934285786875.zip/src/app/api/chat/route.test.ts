import { describe, expect, it, mock } from "bun:test";

// Mock next/server - DO THIS BEFORE IMPORTING THE ROUTE
mock.module("next/server", () => ({
  NextResponse: {
    json: (data: any, init?: any) => {
      const res = {
        status: init?.status || 200,
        json: async () => data,
      };
      return res;
    },
  },
}));

// Mock @/lib/gemini
mock.module("@/lib/gemini", () => ({
  generateChatResponse: mock(() => Promise.resolve("Mocked response")),
  detectPromptInjection: mock(() => false),
  containsPII: mock(() => false),
}));

// Use a dynamic import or require to ensure mocks are applied
const { POST } = await import("./route");

describe("Chat API Route - Input Validation", () => {
  it("should return 400 if messages is missing", async () => {
    const req = {
      json: async () => ({}),
    } as any;

    const response = await POST(req);
    expect(response.status).toBe(400);
    const data = await response.json();
    expect(data.error).toContain("messages");
  });

  it("should return 400 if messages is not an array", async () => {
    const req = {
      json: async () => ({ messages: "not an array" }),
    } as any;

    const response = await POST(req);
    expect(response.status).toBe(400);
    const data = await response.json();
    expect(data.error).toContain("messages");
  });

  it("should return 400 if messages is empty", async () => {
    const req = {
      json: async () => ({ messages: [] }),
    } as any;

    const response = await POST(req);
    expect(response.status).toBe(400);
    const data = await response.json();
    expect(data.error).toContain("messages");
  });

  it("should return 400 if last message is missing content", async () => {
    const req = {
      json: async () => ({
        messages: [{ role: "user" }], // content is missing
      }),
    } as any;

    const response = await POST(req);
    expect(response.status).toBe(400);
    const data = await response.json();
    expect(data.error).toContain("content");
  });
});
