import { describe, expect, test, mock, beforeAll } from "bun:test";

// Mock the Next.js NextResponse
mock.module("next/server", () => {
  return {
    NextResponse: {
      json: (body: any, init?: ResponseInit) => {
        return new Response(JSON.stringify(body), {
          status: init?.status || 200,
          headers: { "Content-Type": "application/json" },
        });
      },
    },
  };
});

// Mock Gemini library to test standard flows
mock.module("@/lib/gemini", () => {
  return {
    generateChatResponse: async () => "Mocked response",
    detectPromptInjection: () => false,
    containsPII: () => false,
  };
});

describe("POST /api/chat", () => {
  let POST: any;

  beforeAll(async () => {
    // Dynamic import to ensure mocks are registered first
    const route = await import("./route");
    POST = route.POST;
  });

  test("should return 400 if messages is not an array", async () => {
    const req = new Request("http://localhost/api/chat", {
      method: "POST",
      body: JSON.stringify({ messages: "not-an-array" }),
    });

    const res = await POST(req);
    const json = await res.json();

    expect(res.status).toBe(400);
    expect(json.error).toBe("Invalid input: messages must be an array.");
  });

  test("should return generic error message on internal error", async () => {
    // Force req.json() to throw to trigger catch block
    const req = new Request("http://localhost/api/chat", {
      method: "POST",
      body: "invalid json",
    });

    const res = await POST(req);
    const json = await res.json();

    expect(res.status).toBe(500);
    expect(json.error).toBe("Terjadi kesalahan pada server AI.");
  });

  test("should handle missing messages property correctly", async () => {
    const req = new Request("http://localhost/api/chat", {
      method: "POST",
      body: JSON.stringify({}),
    });

    const res = await POST(req);
    const json = await res.json();

    expect(res.status).toBe(400);
    expect(json.error).toBe("Invalid input: messages must be an array.");
  });
});
